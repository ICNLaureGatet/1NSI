import csv
import matplotlib.pyplot as plt
from math import sqrt
    
def extractionDonnees(nomFichier):
    """Cette fonction récupère les données d'un fichier csv et renvoie un dictionnaire :
    La liste des descripteurs et la liste de toutes les données"""
    nomDuFichier = nomFichier
    if nomFichier[-4:]!=".csv":
        nomDuFichier+=".csv"
    fichier = open(nomDuFichier,"r",encoding="utf-8")
    extraction=csv.DictReader(fichier,delimiter=";")
    listeJoueurs=[]
    for ligne in extraction:
        listeJoueurs.append(dict(ligne))
    return listeJoueurs

def extraireEquipe(data,equipe):
    """de l'ensemble des listes, on extrait seulement celles d'une équipe
    Parmi les équipes, on trouve "Agen", "Bayonne", "Bordeaux", "Brive", "Castres", "Clermont",
    "La Rochelle", "Lyon", "Montpellier", "Paris", "Pau", Racing92", "Toulon" et "Toulouse"
    On peut aussi écrire "tous" pour avoir tous les joueurs du top 14"""
    return [el for el in data if (el['Equipe'] == equipe or equipe.lower() == "tous")]

def representation(data):
    """data est une liste de joueurs avec leurs caractéristiques.
    On extrait leur taille et poids puis on représente ces données dans un repère
    (une couleur par type de poste la position étant déterminée par la liste des descripteurs)
    Les types de postes sont "Avant", "2ème ligne", "3ème ligne", "Demi", "Trois-Quarts" et "Arrière" """
    dictCouleurs = {"Avant":"tab:blue", "2ème ligne":"tab:red", "3ème ligne":"tab:green", "Demi":"tab:purple", "Trois-Quarts":"tab:brown", "Arrière":"tab:orange"}
    dictMarkers = {"Avant":"x", "2ème ligne":"+", "3ème ligne":"1", "Demi":".", "Trois-Quarts":"*", "Arrière":"^"}
    fig = plt.figure()
    listLabel = []
    for joueur in data:
        #Ce qui suit sert juste à afficher les labels
        if joueur["Type poste"] in listLabel:
            plt.plot(int(joueur["Taille (en cm)"]), int(joueur["Poids (en kg)"]), color=dictCouleurs[joueur["Type poste"]],marker=dictMarkers[joueur["Type poste"]])
        else :
            plt.plot(int(joueur["Taille (en cm)"]), int(joueur["Poids (en kg)"]), color=dictCouleurs[joueur["Type poste"]],marker=dictMarkers[joueur["Type poste"]],label=joueur["Type poste"])
            listLabel.append(joueur["Type poste"])
    #Cette partie sert juste à créer le nom du fichier
    equipe = [joueur["Equipe"] for joueur in data]
    if(equipe.count(equipe[0]) == len(equipe)):
        #c'est que tous les joueurs sont d'une même équipe,
        nomEquipe = data[1]["Equipe"]
    else :
        nomEquipe = "top14"
    plt.xlabel("Taille (en cm)")
    plt.ylabel("Poids (en kg)")

    plt.legend(title=nomEquipe,markerscale = 1.2,frameon = True)
    plt.savefig(nomEquipe+".png")
    plt.show()



joueursTop14 =extractionDonnees('joueursTop14.csv')
Toulouse = extraireEquipe(joueursTop14, 'Toulouse')
representation(Toulouse)

Clermont = extraireEquipe(joueursTop14, 'Clermont')
representation(Clermont)